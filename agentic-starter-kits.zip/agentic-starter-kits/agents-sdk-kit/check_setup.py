"""10-second check that your key, model, and install all work.

Run:  uv run python check_setup.py
"""
import os
import sys

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

if not os.getenv("GROQ_API_KEY"):
    sys.exit("GROQ_API_KEY not found. Copy .env.example to .env and paste your key.")

model = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
client = OpenAI(
    base_url=os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1"),
    api_key=os.environ["GROQ_API_KEY"],
)
reply = client.chat.completions.create(
    model=model,
    messages=[{"role": "user", "content": "Reply with exactly one word: ready"}],
)
print(f"Model: {model}")
print("Reply:", reply.choices[0].message.content)
print("Agents SDK kit OK")
