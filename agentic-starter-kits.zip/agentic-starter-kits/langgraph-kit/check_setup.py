"""10-second check that your key, model, and install all work.

Run:  uv run python check_setup.py
"""
import os
import sys

from dotenv import load_dotenv
from langchain_groq import ChatGroq

load_dotenv()

if not os.getenv("GROQ_API_KEY"):
    sys.exit("GROQ_API_KEY not found. Copy .env.example to .env and paste your key.")

model = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
llm = ChatGroq(model=model)
print(f"Model: {model}")
print("Reply:", llm.invoke("Reply with exactly one word: ready").content)
print("LangGraph kit OK")
