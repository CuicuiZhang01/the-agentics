"""LangGraph starter: a tool-using agent built as an explicit graph.

Run:  uv run python main.py

LangGraph's big idea: YOU draw the control flow. Nodes are functions, edges are
the allowed moves between them, and a shared STATE flows through. Here the graph
loops:  agent -> (tool needed?) -> tools -> agent -> ... -> done.
Try:  "What time is it in UTC, and what is 17 * 23?"
"""
import ast
import operator
import os
from datetime import datetime, timezone
from typing import Annotated, TypedDict

from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_groq import ChatGroq
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition

load_dotenv()

# --- 1. Tools --------------------------------------------------------------
_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow, ast.USub: operator.neg,
}


def _eval(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.operand))
    raise ValueError("only basic arithmetic is allowed")


@tool
def calculate(expression: str) -> str:
    """Evaluate a basic arithmetic expression such as '17 * 23'."""
    return str(_eval(ast.parse(expression, mode="eval").body))


@tool
def get_current_time() -> str:
    """Return the current UTC date and time."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


tools = [calculate, get_current_time]

# --- 2. The model, told about the tools ------------------------------------
llm = ChatGroq(
    model=os.getenv("GROQ_MODEL", "openai/gpt-oss-120b"),
    temperature=0,
)
llm_with_tools = llm.bind_tools(tools)


# --- 3. State: the memory that flows through the graph ---------------------
class State(TypedDict):
    # add_messages APPENDS new messages instead of overwriting the list
    messages: Annotated[list, add_messages]


# --- 4. Nodes: functions that read state and return updates ----------------
def agent(state: State) -> dict:
    return {"messages": [llm_with_tools.invoke(state["messages"])]}


# --- 5. Wire the graph: nodes + edges = control flow -----------------------
builder = StateGraph(State)
builder.add_node("agent", agent)
builder.add_node("tools", ToolNode(tools))
builder.add_edge(START, "agent")
builder.add_conditional_edges("agent", tools_condition)  # tools, or END
builder.add_edge("tools", "agent")  # after a tool runs, go back to the agent

# MemorySaver = the graph remembers each conversation thread between turns
graph = builder.compile(checkpointer=MemorySaver())

if __name__ == "__main__":
    print("Graph structure (paste into https://mermaid.live to see the picture):\n")
    print(graph.get_graph().draw_mermaid())

    print("LangGraph kit. Type 'quit' to exit.\n")
    config = {"configurable": {"thread_id": "demo"}}
    while True:
        user = input("You: ").strip()
        if user.lower() in {"quit", "exit", ""}:
            break
        # stream_mode="updates" shows each node's output as it happens
        for step in graph.stream(
            {"messages": [("user", user)]}, config, stream_mode="updates"
        ):
            for node, update in step.items():
                msg = update["messages"][-1]
                label = "tool call" if getattr(msg, "tool_calls", None) else "output"
                print(f"  [{node}] {label}")
        print(f"\nAssistant: {msg.content}\n")
