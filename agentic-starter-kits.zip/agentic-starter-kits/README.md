# Agentic Starter Kits

Three small, independent [uv](https://docs.astral.sh/uv/) projects. Each one is the
smallest useful starting point for a different way of building agentic workflows.

| Kit | Idea | Run it |
| :--- | :--- | :--- |
| `crewai-kit/` | A **team of role-playing agents** working through tasks | `uv run python main.py "topic"` |
| `agents-sdk-kit/` | One agent with **tools and handoffs** to specialists | `uv run python main.py` |
| `langgraph-kit/` | An agent as an **explicit graph** you draw yourself | `uv run python main.py` |

All three use a free [Groq](https://console.groq.com/keys) API key.

## Setup (once)

1. Copy `.env.example` to `.env` in this folder and paste your Groq key.
   - Mac/Linux: `cp .env.example .env`
   - Windows PowerShell: `Copy-Item .env.example .env`
2. In each kit folder, install and check:

```
cd crewai-kit
uv sync
uv run python check_setup.py
```

One `.env` here serves all three kits. See `agentic_workflow_guide.md` for the full walkthrough.
